# Sun Son Solar — Registration Forms Only

Ito yung customer at employee registration forms lang (HTML/CSS/JS/PHP,
CodeIgniter 3). Wala pang login, dashboard, o product catalog dito —
kung kailangan mo na yung buong system ulit, sabihin mo lang.
Wala rin akong ginawang database — `database/schema.sql` lang, i-run niyo
na lang mismo sa phpMyAdmin kapag ready na.

## Setup sa XAMPP

1. Download ang CodeIgniter 3: https://codeigniter.com/download
2. I-extract sa `C:\xampp\htdocs\sunson-solar-registration\`
3. Palitan yung `application/` folder galing sa CodeIgniter download ng
   `application/` folder na nasa zip na ito.
4. Kopyahin din yung `assets/` folder papunta sa parehong lokasyon
   (kasabay ng `system/` at `index.php`).
5. Sa phpMyAdmin, i-import ang `database/schema.sql` — gagawa ito ng
   `sunson_solar` database at ng `users` table.
6. I-update ang `application/config/database.php` kung iba yung MySQL
   username/password niyo (default XAMPP: `root`, walang password).

## URLs

- `http://localhost/sunson-solar-registration/register/customer`
- `http://localhost/sunson-solar-registration/register/employee`

## Fields

- **Customer**: First name, Last name, Middle name, Birthdate, Gender,
  Email, Phone, Address, Username, Password.
- **Employee**: parehong fields + Department (Field Ops — Technician,
  Dispatch, IT, Sales, Administration).

Iisang `users` table lang para sa dalawa, may `role` column
('customer'/'employee') at `user_id` bilang **primary key**. Naka-hash
na yung password (`password_hash()`) bago i-save — hindi plain text.
