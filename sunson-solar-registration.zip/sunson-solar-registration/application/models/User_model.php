<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * `users` table — one table for customers, employees and admins,
 * told apart by the `role` column. `user_id` is the primary key.
 */
class User_model extends CI_Model
{
	protected $table = 'users';

	public function __construct()
	{
		parent::__construct();
	}

	public function username_exists($username)
	{
		return $this->db->get_where($this->table, ['username' => $username])->num_rows() > 0;
	}

	public function email_exists($email)
	{
		return $this->db->get_where($this->table, ['email' => $email])->num_rows() > 0;
	}

	/**
	 * $data must already contain a hashed password.
	 * $role is 'customer' or 'employee'.
	 */
	public function create_user(array $data, $role)
	{
		$data['role'] = $role;
		$data['created_at'] = date('Y-m-d H:i:s');

		$this->db->insert($this->table, $data);

		return $this->db->insert_id();
	}
}
