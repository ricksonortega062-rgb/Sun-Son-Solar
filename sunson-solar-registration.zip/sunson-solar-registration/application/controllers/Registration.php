<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
	}

	// Default landing page for this package.
	public function index()
	{
		redirect('register/customer');
	}

	// ---- CUSTOMER REGISTRATION -----------------------------------------

	public function customer()
	{
		$data['title'] = 'Create a Customer Account';

		if ($this->input->method() === 'post') {
			$result = $this->_handle_registration('customer', NULL);
			if ($result === TRUE) {
				$data['success'] = 'Account created! You may now log in once the login page is added.';
			} else {
				$data['error'] = $result;
			}
		}

		$this->load->view('templates/header', $data);
		$this->load->view('auth/register_customer', $data);
		$this->load->view('templates/footer');
	}

	// ---- EMPLOYEE REGISTRATION ------------------------------------------
	// Used by the head technician/dispatcher and other field/office staff
	// to register themselves with their department.

	public function employee()
	{
		$data['title'] = 'Create an Employee Account';

		if ($this->input->method() === 'post') {
			$department = $this->input->post('department', TRUE);
			$result = $this->_handle_registration('employee', $department);
			if ($result === TRUE) {
				$data['success'] = 'Account created! You may now log in once the login page is added.';
			} else {
				$data['error'] = $result;
			}
		}

		$this->load->view('templates/header', $data);
		$this->load->view('auth/register_employee', $data);
		$this->load->view('templates/footer');
	}

	// ---- Shared registration handling ------------------------------------

	private function _handle_registration($role, $department)
	{
		$this->form_validation->set_rules('first_name', 'First name', 'required|trim');
		$this->form_validation->set_rules('last_name', 'Last name', 'required|trim');
		$this->form_validation->set_rules('birthdate', 'Birthdate', 'required');
		$this->form_validation->set_rules('gender', 'Gender', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required|valid_email|trim');
		$this->form_validation->set_rules('phone', 'Phone number', 'required|trim');
		$this->form_validation->set_rules('address', 'Address', 'required|trim');
		$this->form_validation->set_rules('username', 'Username', 'required|trim|min_length[5]|alpha_numeric');
		$this->form_validation->set_rules('password', 'Password', 'required|min_length[8]');
		$this->form_validation->set_rules('confirm_password', 'Confirm password', 'required|matches[password]');

		if ($role === 'employee') {
			$this->form_validation->set_rules('department', 'Department', 'required');
		}

		if ($this->form_validation->run() === FALSE) {
			return validation_errors();
		}

		if ($this->User_model->username_exists($this->input->post('username', TRUE))) {
			return 'That username is already taken.';
		}
		if ($this->User_model->email_exists($this->input->post('email', TRUE))) {
			return 'That email is already registered.';
		}

		$data = [
			'first_name'  => $this->input->post('first_name', TRUE),
			'last_name'   => $this->input->post('last_name', TRUE),
			'middle_name' => $this->input->post('middle_name', TRUE),
			'birthdate'   => $this->input->post('birthdate', TRUE),
			'gender'      => $this->input->post('gender', TRUE),
			'email'       => $this->input->post('email', TRUE),
			'phone'       => $this->input->post('phone', TRUE),
			'address'     => $this->input->post('address', TRUE),
			'username'    => $this->input->post('username', TRUE),
			'password'    => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
			'department'  => $department,
		];

		$this->User_model->create_user($data, $role);

		return TRUE;
	}
}
