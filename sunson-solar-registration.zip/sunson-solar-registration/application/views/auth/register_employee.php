<section class="auth-section">
	<div class="wrap auth-wrap">
		<div class="auth-card auth-card--wide">
			<h1>Create an Employee Account</h1>
			<p class="auth-card__sub">For technicians, dispatchers and office staff joining Sun Son Solar.</p>

			<?php if (! empty($success)): ?>
				<div class="alert alert--success"><?= $success ?></div>
			<?php endif; ?>

			<form method="post" action="<?= base_url('register/employee') ?>" class="form form--grid">
				<label>First Name
					<input type="text" name="first_name" required value="<?= set_value('first_name') ?>">
				</label>
				<label>Last Name
					<input type="text" name="last_name" required value="<?= set_value('last_name') ?>">
				</label>
				<label>Middle Name
					<input type="text" name="middle_name" value="<?= set_value('middle_name') ?>">
				</label>
				<label>Birthdate
					<input type="date" name="birthdate" required>
				</label>
				<label>Gender
					<select name="gender" required>
						<option value="">Select…</option>
						<option value="Female">Female</option>
						<option value="Male">Male</option>
						<option value="Other">Other</option>
					</select>
				</label>
				<label>Department
					<select name="department" required>
						<option value="">Select…</option>
						<option value="Field Operations - Technician">Field Operations — Technician</option>
						<option value="Dispatch">Dispatch</option>
						<option value="IT">IT</option>
						<option value="Sales">Sales</option>
						<option value="Administration">Administration</option>
					</select>
				</label>
				<label>Email
					<input type="email" name="email" required value="<?= set_value('email') ?>">
				</label>
				<label>Phone Number
					<input type="tel" name="phone" required value="<?= set_value('phone') ?>">
				</label>
				<label class="span-2">Address
					<input type="text" name="address" required value="<?= set_value('address') ?>">
				</label>
				<label>Username
					<input type="text" name="username" required value="<?= set_value('username') ?>">
				</label>
				<label></label>
				<label>Password
					<input type="password" name="password" required minlength="8">
				</label>
				<label>Confirm Password
					<input type="password" name="confirm_password" required minlength="8">
				</label>

				<button type="submit" class="btn btn--solid btn--full span-2">Create Account</button>
			</form>

			<p class="auth-card__foot">Customer ka? <a href="<?= base_url('register/customer') ?>">Customer sign up dito</a></p>
		</div>
	</div>
</section>
