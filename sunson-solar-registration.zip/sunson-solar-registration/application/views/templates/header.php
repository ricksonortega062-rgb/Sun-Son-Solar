<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?= isset($title) ? $title . ' — Sun Son Solar' : 'Sun Son Solar' ?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?= base_url('assets/css/style.css') ?>">
</head>
<body>

<header class="site-nav">
	<div class="wrap site-nav__inner">
		<a href="<?= base_url('register/customer') ?>" class="brand">
			<span class="brand__mark" aria-hidden="true"></span>
			Sun Son Solar
		</a>

		<button class="nav-toggle" id="navToggle" aria-label="Toggle menu" aria-expanded="false">
			<span></span><span></span><span></span>
		</button>

		<nav class="nav-links" id="navLinks">
			<a href="<?= base_url('register/customer') ?>">Customer Sign Up</a>
			<a href="<?= base_url('register/employee') ?>" class="btn btn--solid">Employee Sign Up</a>
		</nav>
	</div>
</header>

<main>
<?php if (! empty($error)): ?>
	<div class="wrap"><div class="alert alert--error"><?= $error ?></div></div>
<?php endif; ?>
