</main>

<footer class="site-footer">
	<div class="wrap site-footer__inner">
		<div>
			<p class="site-footer__brand">Sun Son Solar</p>
			<p class="site-footer__tag">Founded by Katherine &amp; Santino "Sonny" Sinagaraw</p>
		</div>
	</div>
	<p class="site-footer__copy">&copy; <?= date('Y') ?> Sun Son Solar.</p>
</footer>

<script src="<?= base_url('assets/js/main.js') ?>"></script>
</body>
</html>
