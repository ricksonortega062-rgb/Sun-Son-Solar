<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'registration';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['register/customer'] = 'registration/customer';
$route['register/employee'] = 'registration/employee';
